using UnityEngine;

public class HoarderBugItem
{
	public GrabbableObject itemGrabbableObject;

	public Vector3 itemNestPosition;

	public HoarderBugItemStatus status;

	public HoarderBugItem(GrabbableObject newObject, HoarderBugItemStatus newStatus, Vector3 bugNestPosition)
	{
	}
}

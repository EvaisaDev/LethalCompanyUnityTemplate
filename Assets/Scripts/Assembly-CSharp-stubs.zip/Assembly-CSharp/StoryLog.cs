using Unity.Netcode;

public class StoryLog : NetworkBehaviour
{
	public int storyLogID;

	private bool collected;

	public void CollectLog()
	{
	}

	private void Start()
	{
	}

	private void RemoveLogCollectible()
	{
	}

	public void SetStoryLogID(int logID)
	{
	}
}

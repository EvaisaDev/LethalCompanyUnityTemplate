using UnityEngine;

public class PowerSwitchable : MonoBehaviour
{
	public OnSwitchPowerEvent powerSwitchEvent;

	public void OnPowerSwitch(bool switchedOn)
	{
	}

	private void OnEnable()
	{
	}

	private void OnDisable()
	{
	}
}

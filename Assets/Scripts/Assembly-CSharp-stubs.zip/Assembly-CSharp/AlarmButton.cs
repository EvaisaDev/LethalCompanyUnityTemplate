using UnityEngine;

public class AlarmButton : MonoBehaviour
{
	private Animator buttonAnimator;

	public float timeSincePushing;

	public void PushAlarmButton()
	{
	}

	private void Update()
	{
	}
}

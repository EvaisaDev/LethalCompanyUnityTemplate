using UnityEngine;

public class ToggleAllLightsInContainer : MonoBehaviour
{
	public Material offMaterial;

	public Material onMaterial;

	public int materialIndex;

	public void ToggleLights(bool on)
	{
	}
}

using UnityEngine;
using UnityEngine.InputSystem;

public class DisableMouseInMenu : MonoBehaviour
{
	public PlayerActions actions;

	private void Awake()
	{
	}

	private void OnEnable()
	{
	}

	private void OnDisable()
	{
	}

	private void Look_performed(InputAction.CallbackContext context)
	{
	}

	private void Move_performed(InputAction.CallbackContext context)
	{
	}
}

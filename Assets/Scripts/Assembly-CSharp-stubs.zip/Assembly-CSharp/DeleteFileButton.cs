using TMPro;
using UnityEngine;

public class DeleteFileButton : MonoBehaviour
{
	public int fileToDelete;

	public AudioClip deleteFileSFX;

	public TextMeshProUGUI deleteFileText;

	public void SetFileToDelete(int fileNum)
	{
	}

	public void DeleteFile()
	{
	}
}

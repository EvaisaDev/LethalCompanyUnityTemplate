namespace DunGen.Graph
{
	public enum NodeType
	{
		Normal = 0,
		Start = 1,
		Goal = 2
	}
}

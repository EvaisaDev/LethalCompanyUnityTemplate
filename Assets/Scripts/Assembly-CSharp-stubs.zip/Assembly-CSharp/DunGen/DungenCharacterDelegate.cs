namespace DunGen
{
	public delegate void DungenCharacterDelegate(DungenCharacter character);
}

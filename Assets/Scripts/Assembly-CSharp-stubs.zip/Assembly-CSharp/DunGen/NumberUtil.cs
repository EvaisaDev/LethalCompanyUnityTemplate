namespace DunGen
{
	public static class NumberUtil
	{
		public static float ClampToNearest(float value, params float[] possibleValues)
		{
			return 0f;
		}
	}
}

using UnityEngine;

namespace DunGen
{
	public static class EditorConstants
	{
		public static readonly Color DoorRectColour;

		public static readonly Color DoorDirectionColour;

		public static readonly Color DoorUpColour;
	}
}

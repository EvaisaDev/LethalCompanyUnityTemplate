namespace DunGen
{
	public delegate bool SocketConnectionDelegate(DoorwaySocket a, DoorwaySocket b);
}

namespace DunGen
{
	public enum LocalPropSetCountMode
	{
		Random = 0,
		DepthBased = 1,
		DepthMultiply = 2
	}
}

namespace DunGen
{
	public enum GameObjectFilter
	{
		Scene = 1,
		Asset = 2,
		All = 3
	}
}

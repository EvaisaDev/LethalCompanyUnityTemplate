using UnityEngine;

namespace DunGen
{
	public static class DebugDraw
	{
		public static void Bounds(Bounds localBounds, Matrix4x4 transform, Color colour, float duration = 0f, bool depthTest = false)
		{
		}
	}
}

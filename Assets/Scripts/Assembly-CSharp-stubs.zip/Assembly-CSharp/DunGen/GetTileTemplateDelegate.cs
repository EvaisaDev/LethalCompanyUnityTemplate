using UnityEngine;

namespace DunGen
{
	public delegate TileProxy GetTileTemplateDelegate(GameObject prefab);
}

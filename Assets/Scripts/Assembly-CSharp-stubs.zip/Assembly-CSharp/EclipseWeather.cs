using UnityEngine;

public class EclipseWeather : MonoBehaviour
{
	private void OnEnable()
	{
	}
}

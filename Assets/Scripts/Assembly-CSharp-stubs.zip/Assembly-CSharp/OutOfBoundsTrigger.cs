using UnityEngine;

public class OutOfBoundsTrigger : MonoBehaviour
{
	private StartOfRound playersManager;

	public bool disableWhenRoundStarts;

	private void Start()
	{
	}

	private void OnTriggerEnter(Collider other)
	{
	}
}

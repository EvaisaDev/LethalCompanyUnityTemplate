using UnityEngine;

public class CleanPlayerBodyTrigger : MonoBehaviour
{
	private bool enableCleaning;

	public void EnableCleaningTrigger(bool enable)
	{
	}

	private void OnTriggerStay(Collider other)
	{
	}
}

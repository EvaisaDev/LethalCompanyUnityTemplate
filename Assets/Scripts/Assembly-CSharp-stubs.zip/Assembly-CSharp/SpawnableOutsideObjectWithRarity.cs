using System;
using UnityEngine;

[Serializable]
public class SpawnableOutsideObjectWithRarity
{
	public SpawnableOutsideObject spawnableObject;

	public AnimationCurve randomAmount;
}

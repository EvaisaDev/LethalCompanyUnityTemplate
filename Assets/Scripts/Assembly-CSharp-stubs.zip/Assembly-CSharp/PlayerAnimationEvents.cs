using GameNetcodeStuff;
using UnityEngine;

public class PlayerAnimationEvents : MonoBehaviour
{
	public PlayerControllerB thisPlayerController;

	public void PlayFootstepServer()
	{
	}

	public void PlayFootstepLocal()
	{
	}

	public void LimpForward()
	{
	}

	public void LockArmsToCamera()
	{
	}

	public void UnlockArmsFromCamera()
	{
	}
}

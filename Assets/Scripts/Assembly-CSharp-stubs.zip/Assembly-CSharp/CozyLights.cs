using UnityEngine;

public class CozyLights : MonoBehaviour
{
	private bool cozyLightsOn;

	public Animator cozyLightsAnimator;

	private void Update()
	{
	}
}

public class RedPillAnomaly : Anomaly
{
}

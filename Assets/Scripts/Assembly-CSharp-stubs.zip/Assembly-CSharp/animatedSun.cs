using UnityEngine;

public class animatedSun : MonoBehaviour
{
	public Light indirectLight;

	public Light directLight;

	private void Start()
	{
	}

	private void Update()
	{
	}
}

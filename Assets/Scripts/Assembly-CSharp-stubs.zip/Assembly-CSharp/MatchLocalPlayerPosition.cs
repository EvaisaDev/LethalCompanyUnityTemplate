using UnityEngine;

public class MatchLocalPlayerPosition : MonoBehaviour
{
	private void LateUpdate()
	{
	}
}

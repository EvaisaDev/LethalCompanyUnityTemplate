public class BinocularsItem : GrabbableObject
{
}

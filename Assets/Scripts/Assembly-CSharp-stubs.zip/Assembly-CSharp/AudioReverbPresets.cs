using UnityEngine;

public class AudioReverbPresets : MonoBehaviour
{
	public AudioReverbTrigger[] audioPresets;
}

public class PhysicsProp : GrabbableObject
{
}

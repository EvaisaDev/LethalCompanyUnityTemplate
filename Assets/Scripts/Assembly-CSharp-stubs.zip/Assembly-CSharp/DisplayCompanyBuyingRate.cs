using TMPro;
using UnityEngine;

public class DisplayCompanyBuyingRate : MonoBehaviour
{
	public TextMeshProUGUI displayText;

	private void Update()
	{
	}
}

public enum DayMode
{
	None = -1,
	Dawn = 0,
	Noon = 1,
	Sundown = 2,
	Midnight = 3
}

using System.Runtime.CompilerServices;
using UnityEngine;

public class SteamManager : MonoBehaviour
{
	public static SteamManager Instance
	{
		[CompilerGenerated]
		get
		{
			return null;
		}
		[CompilerGenerated]
		private set
		{
		}
	}

	private void Awake()
	{
	}

	private void OnDisable()
	{
	}

	private void Update()
	{
	}
}

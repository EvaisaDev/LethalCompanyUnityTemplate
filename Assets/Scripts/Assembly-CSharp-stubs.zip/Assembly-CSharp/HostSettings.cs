public class HostSettings
{
	public string lobbyName;

	public bool isLobbyPublic;

	public HostSettings(string name, bool isPublic)
	{
	}
}

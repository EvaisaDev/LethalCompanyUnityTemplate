using System;

[Serializable]
public class RandomWeatherWithVariables
{
	public LevelWeatherType weatherType;

	public int weatherVariable;

	public int weatherVariable2;
}

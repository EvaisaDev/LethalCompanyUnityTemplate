using UnityEngine;

public class facePlayerOnAxis : MonoBehaviour
{
	private Transform playerCamera;

	public Transform turnAxis;

	private bool gotPlayer;

	private void Update()
	{
	}
}

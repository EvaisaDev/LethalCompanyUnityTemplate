using System;
using UnityEngine.Events;

[Serializable]
public class GrabbableObjectEvent : UnityEvent
{
}

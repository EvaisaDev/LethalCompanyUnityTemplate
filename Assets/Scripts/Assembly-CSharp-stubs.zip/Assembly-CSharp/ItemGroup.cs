using UnityEngine;

[CreateAssetMenu(menuName = "ScriptableObjects/ItemGroup", order = 2)]
public class ItemGroup : ScriptableObject
{
	public string itemSpawnTypeName;
}

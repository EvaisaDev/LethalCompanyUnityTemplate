public enum LevelWeatherType
{
	None = -1,
	DustClouds = 0,
	Rainy = 1,
	Stormy = 2,
	Foggy = 3,
	Flooded = 4,
	Eclipsed = 5
}

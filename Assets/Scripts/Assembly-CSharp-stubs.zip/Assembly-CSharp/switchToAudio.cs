using System;
using UnityEngine;

[Serializable]
public class switchToAudio
{
	public AudioSource audio;

	public AudioClip changeToClip;

	public bool stopAudio;

	public bool changeAudioVolume;

	public float audioVolume;
}

public enum TurretMode
{
	Detection = 0,
	Charging = 1,
	Firing = 2,
	Berserk = 3
}
